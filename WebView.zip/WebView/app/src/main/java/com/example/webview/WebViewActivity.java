package com.example.webview;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class WebViewActivity extends AppCompatActivity {
    private WebView WVhtml;
private Button break_btn;
    private Button forward_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        WVhtml = (WebView) findViewById(R.id.webView);
        break_btn=findViewById(R.id.break_btn);
        forward_btn=findViewById(R.id.f_btn);
        WVhtml.getSettings().setJavaScriptEnabled(true);
        WVhtml.loadUrl("https://www.baidu.com");
        WVhtml.setWebViewClient(new MyWebViewClient());
        WVhtml.setWebChromeClient(new MyWebChromeClient());
        break_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              WVhtml.goBack();
            }
        });
        forward_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WVhtml.goForward();
            }
        });
    }
        class MyWebViewClient extends WebViewClient {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override  //WebView代表是当前的WebView
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                //表示在当前的WebView继续打开网页
                view.loadUrl(request.getUrl().toString());
                return true;
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d("WebView", "开始访问网页");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d("WebView", "访问网页结束");
            }
        }
    class MyWebChromeClient extends WebChromeClient {
        @Override //监听加载进度
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
        }
        @Override//接受网页标题
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            //把当前的Title设置到Activity的title上显示
            setTitle(title);
        }
    }

//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        //如果按返回键，此时WebView网页可以后退
//        if (keyCode== KeyEvent.KEYCODE_BACK&&WVhtml.canGoBack()){
//            WVhtml.goBack();
//            return true;
//        }
//        return super.onKeyDown(keyCode, event);
//    }

    }